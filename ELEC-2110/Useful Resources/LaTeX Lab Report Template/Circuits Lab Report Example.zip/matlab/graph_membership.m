function graph_membership(members)
% Create Membership Function Graphic
members_length = length(members);
members_range = max(members);

a = linspace(0, members_range, 200);
a_length = length(a);

f = zeros(a_length, members_length);

for j=1:a_length,
    f(j,:)=fuzzify(a(j), members);
end

hold on;
for i=1:members_length;
    plot(a,f(:,i),'k');
end
hold off;
